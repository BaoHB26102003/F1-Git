/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

/**
 *
 * @author ASUS
 */
public class Products {

    @Override
    public String toString() {
        return "Products{" + "productID=" + productID + ", productName=" + productName + ", productPrice=" + productPrice + ", productImg=" + productImg + ", productCategory=" + productCategory + ", productDescription=" + productDescription + ", productSize=" + productSize + ", totalQuantity=" + totalQuantity + '}';
    }

   

    private int productID;
    private String productName;
    private double productPrice;
    private String productImg;

    public String getProductCategory() {
        return productCategory;
    }

    public void setProductCategory(String productCategory) {
        this.productCategory = productCategory;
    }

    public Products(String productCategory) {
        this.productCategory = productCategory;
    }
    private String productCategory;
    private String productDescription;
    private String productSize;
    private int totalQuantity;
   


    
    
      public Products(int productID, String productName, double productPrice, int totalQuantity, String productImg, String productDescription) {
        this.productID = productID;
        this.productName = productName;
        this.productPrice = productPrice;
        this.totalQuantity = totalQuantity;
        this.productImg = productImg;
        
        this.productDescription = productDescription;
    }
    public Products(int productID, String productName, double productPrice, String productImg,String productCategory, String productDescription, int totalQuantity) {
        this.productID = productID;
        this.productName = productName;
        this.productPrice = productPrice;
        this.productImg = productImg;
        this.productCategory= productCategory;
        this.productDescription = productDescription;
        this.totalQuantity = totalQuantity;
    }

    public Products(int productID, String productName, double productPrice, String productImg,String productCategory,  String productDescription, String productSize, int totalQuantity) {
        this.productID = productID;
        this.productName = productName;
        this.productPrice = productPrice;
        this.productImg = productImg;
        this.productCategory= productCategory;
        this.productDescription = productDescription;
        this.productSize = productSize;
        this.totalQuantity = totalQuantity;
    }

    public Products(int productID, String productName, double productPrice, String productImg,String productCategory,  String productDescription) {
        this.productID = productID;
        this.productName = productName;
        this.productPrice = productPrice;
        this.productImg = productImg;
       this.productCategory= productCategory;
        this.productDescription = productDescription;
    }

  
   

    public Products() {

    }

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }

    public String getProductImg() {
        return productImg;
    }

    public void setProductImg(String productImg) {
        this.productImg = productImg;
    }

 
    

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public String getProductSize() {
        return productSize;
    }

    public void setProductSize(String productSize) {
        this.productSize = productSize;
    }

    public int getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(int totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

}
