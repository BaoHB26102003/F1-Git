/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOs;

import DBContext.DBConnection;

import Models.Products;
import Models.Sizes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ASUS
 */
public class ProductDAO extends DBConnection {

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    public ProductDAO() {
        conn = DBContext.DBConnection.getConnection();
    }

    //list product homepage
    public List<Products> getAllProducts() {
        // List<Product> list = new ArrayList<>();
        ArrayList<Products> list = new ArrayList<>();
        String query = "SELECT * FROM Products";
        try {

            conn = DBConnection.getConnection();//mo ta ket noi sql
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();

            while (rs.next()) {
                list.add(new Products(rs.getInt("productID"),
                        rs.getString("productName"),
                        rs.getFloat("productPrice"),
                        rs.getString("productImg"),
                        rs.getString("productCategory"),
                        rs.getString("productDescription")));
            }

        } catch (SQLException e) {
            System.out.println(e);
            // Handle any potential database errors here
        }

        return list;
    }

    //all product of staff management
    public List<Products> getAllProductsAndTotal() {
        List<Products> products = new ArrayList<>();

        try (
                 Statement statement = conn.createStatement()) {
            String query = "SELECT p.productID, p.productName, p.productPrice, p.productImg, p.productCategory, p.productDescription, COALESCE(SUM(s.productQuantity), 0) AS totalQuantity\n"
                    + "FROM Products p\n"
                    + "LEFT JOIN Sizes s ON p.productID = s.productID\n"
                    + "GROUP BY p.productID, p.productName, p.productPrice, p.productImg, p.productCategory, p.productDescription;";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                int productID = resultSet.getInt("productID");
                String productName = resultSet.getString("productName");
                double productPrice = resultSet.getDouble("productPrice");
                String productImg = resultSet.getString("productImg");
                String productMaterial = resultSet.getString("productCategory");
                String productType = resultSet.getString("productDescription");
                int totalQuantity = resultSet.getInt("totalQuantity");
                Products product = new Products(productID, productName, productPrice, productImg, productMaterial, productType, totalQuantity);
                products.add(product);

            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle any potential database errors here
        }

        return products;
    }

    //product detail
    public Products getProductById(int id) {
        String query = "SELECT P.*, S.productSize, S.productQuantity "
                + "FROM [Products] P "
                + "LEFT JOIN [Sizes] S ON P.productID = S.productID "
                + "WHERE P.productID = ?";
        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Products(
                        rs.getInt("productID"),
                        rs.getString("productName"),
                        rs.getDouble("productPrice"),
                        rs.getString("productImg"),
                        rs.getString("productDescription"),
                        rs.getString("productSize"), // Thêm thông tin từ bảng Size
                        rs.getInt("productQuantity") // Thêm thông tin từ bảng Size
                );
            }

        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return null;
    }

    //add product by staff
    public void addProduct(String productName, String productPrice, String size, int productQuantity, String productImg, String productDescription, String productCategory) {
        String productSql = "INSERT INTO [dbo].[Products] ([productName], [productPrice], [productImg], [productCategory], [productDescription]) VALUES (?, ?, ?, ?, ?)";
        String sizeSql = "INSERT INTO [dbo].[Sizes] ([productID], [productSize], [productQuantity]) VALUES (?, ?, ?)";

        try {
            // Insert into Product table
            PreparedStatement productStatement = conn.prepareStatement(productSql, Statement.RETURN_GENERATED_KEYS);

            productStatement.setString(1, productName);
            productStatement.setString(2, productPrice);
            productStatement.setString(3, productImg);
            productStatement.setString(4, productDescription);
            productStatement.setString(5, productCategory);

            int rowsInsertedProduct = productStatement.executeUpdate();

            if (rowsInsertedProduct > 0) {
                // Retrieve the generated productID
                ResultSet generatedKeys = productStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int productID = generatedKeys.getInt(1);

                    // Insert into Size table
                    PreparedStatement sizeStatement = conn.prepareStatement(sizeSql);
                    sizeStatement.setInt(1, productID);
                    sizeStatement.setString(2, size);
                    sizeStatement.setInt(3, productQuantity);

                    int rowsInsertedSize = sizeStatement.executeUpdate();

                    if (rowsInsertedSize > 0) {
                        System.out.println("Thêm sản phẩm thành công.");
                    } else {
                        System.out.println("Không thể thêm sản phẩm vào bảng Size.");
                    }
                }
            } else {
                System.out.println("Không thể thêm sản phẩm vào bảng Product.");
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle SQLException appropriately
        }
    }

    //delete
//    public void DeleteProductByStaff(String productID) {
//        try {
//            // Xóa các bản ghi từ bảng Size liên quan đến sản phẩm
//            String deleteSizeSql = "DELETE FROM Sizes WHERE productID = ?";
//            try ( PreparedStatement deleteSizeStatement = conn.prepareStatement(deleteSizeSql)) {
//                deleteSizeStatement.setString(1, productID);
//                deleteSizeStatement.executeUpdate();
//            }
//
//            // Xóa sản phẩm từ bảng Product
//            String deleteProductSql = "DELETE FROM Product WHERE productID = ?";
//            try ( PreparedStatement deleteProductStatement = conn.prepareStatement(deleteProductSql)) {
//                deleteProductStatement.setString(1, productID);
//
//                int rowsDeleted = deleteProductStatement.executeUpdate();
//
//                if (rowsDeleted > 0) {
//                    System.out.println("Xóa sản phẩm thành công!");
//                } else {
//                    System.out.println("Không có sản phẩm nào bị xóa.");
//                }
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//            // Xử lý bất kỳ lỗi cơ sở dữ liệu nào ở đây
//        }
//    }

    public void staffdelete(int productID) {
        try {
            String deleleSize = "DELETE FROM Sizes where productID =?";
            try(PreparedStatement deleteS = conn.prepareStatement(deleleSize)){
                deleteS.setInt(1, productID);
                deleteS.executeUpdate();
            }
            String deleteProduct = "DELETE FROM Products where productID = ? ";
            try (
                PreparedStatement deleteP = conn.prepareStatement(deleteProduct)){
                deleteP.setInt(1, productID);
                deleteP.executeUpdate();
            }           
        } catch (SQLException e) {
            System.out.println("Xoa");
        }
    }

    //search category
    public ArrayList<Products> getProduct(String search, int index, String sort, String category) {
        String sortby = "";
        switch (sort) {
            case "1":
                sortby = "order by p.productName asc";
                break;
            case "2":
                sortby = "order by p.productPrice asc";
                break;
            case "3":
                sortby = "order by p.productPrice desc";
                break;
            default:
                sortby = "order by p.productName desc";
                break;

        }
        ArrayList<Products> list = new ArrayList<>();
        String sql = "  select * from [Products] p where p.productName like ? and [productCategory] like ? "
                + sortby
                + "  OFFSET ? ROWS FETCH NEXT 8  ROWS ONLY"; // 6 0-2,2-4,4-6
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "%" + search + "%"); // Short   %h%  zzzhqwoeoqw hqoweoqwe qưuioeqioweioh
            ps.setString(2, "%" + category + "%");
            ps.setInt(3, (index - 1) * 8);
            ResultSet resultSet = ps.executeQuery();
            while (resultSet.next()) {
                int productID = resultSet.getInt("productID");
                String productName = resultSet.getString("productName");
                double productPrice = resultSet.getDouble("productPrice");
                String productImg = resultSet.getString("productImg");
                String productCategory = resultSet.getString("productCategory");
                String productDescription = resultSet.getString("productDescription");
                Products product = new Products(productID, productName, productPrice, productImg, productCategory, productDescription);
                list.add(product);
            }
        } catch (Exception e) {
        }
        return list;
    }

    public List<Products> getCategory() {
        ArrayList<Products> listCate = new ArrayList<>();
        String query = "SELECT DISTINCT productCategory FROM Products";
        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                listCate.add(new Products(rs.getString("productCategory")));
            }

        } catch (SQLException e) {
            System.out.println(e);
        }
        return listCate;

    }

    public static void main(String[] args) {
        ProductDAO productDAO = new ProductDAO(); // Replace with your actual database connection class
        List<Products> distinctCategories = productDAO.getCategory();

        // Displaying distinct product categories
        System.out.println("Distinct Product Categories:");
        for (Products product : distinctCategories) {
            System.out.println(product.getProductCategory());
        }
    }

    public List<Sizes> getSize(int productID) {
        List<Sizes> sizes = new ArrayList<>();
        String query = "SELECT * FROM Sizes WHERE productID = ?";

        try {
            conn = DBConnection.getConnection(); // Get SQL connection
            ps = conn.prepareStatement(query);
            ps.setInt(1, productID);  // Set the parameter before executing the query
            rs = ps.executeQuery();

            // Process the result set
            while (rs.next()) {
                // Create a Size object and add it to the list
                Sizes size = new Sizes(
                        rs.getInt("productID"),
                        rs.getString("productSize"),
                        rs.getInt("productQuantity")
                );
                sizes.add(size);
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Handle SQLException appropriately
        } finally {
            // Close resources (result set, statement, and connection)
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace(); // Handle closing exceptions
            }
        }

        return sizes;
    }

    public int getNumberProduct(String search) {
        ArrayList<Products> list = new ArrayList<>();
        String sql = "  select count(*) from Products p where p.productName like ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "%" + search + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
        }
        return 0;
    }

}
